# Portal-Gastronomía

Sistema de control de pañol gastronómico: **HTML + CSS + JavaScript + Python (Django)**.
Los usuarios (login y registro) y todo el inventario se guardan en una base de datos **SQLite** (`db.sqlite3`).

## Cómo ejecutarlo (PC o Termux)

```bash
pip install -r requirements.txt      # en Termux: pkg install python && pip install django
python manage.py migrate             # crea db.sqlite3 y carga los datos de ejemplo (solo la primera vez)
python manage.py runserver 0.0.0.0:8000
```

Abre http://127.0.0.1:8000/ en el navegador.

## Cuentas de ejemplo

| Rol                    | RUT          | Contraseña       |
|------------------------|--------------|------------------|
| Administrador/a        | 11111111-1   | Admin1234        |
| Encargado/a de cocina  | 22222222-2   | Cocina1234       |
| Estudiante             | 33333333-3   | Estudiante1234   |
| Docente                | 44444444-4   | Docente1234      |

También puedes crear una cuenta en `/registro/`.

## Estructura

- `config/` – configuración de Django (SQLite, sesiones, CSRF).
- `portal/models.py` – tablas de SQLite.
- `portal/api.py` – API JSON que usa el navegador (login, registro, lectura y guardado de datos, permisos por rol).
- `portal/seed.py` – datos de ejemplo (se cargan solos con `migrate`).
- `portal/views.py`, `portal/urls.py` – páginas y endpoint `/api/validar-rut/`.
- `portal/rut.py` – validación de RUT (módulo 11).
- `portal/templates/portal/` – login, registro y panel (HTML).
- `portal/static/portal/css/styles.css` – estilos.
- `portal/static/portal/js/app.js` – lógica de pantallas y roles (habla con la API, ya no usa localStorage).
- `portal/tests.py` – pruebas (`python manage.py test`).

## Tablas (antes eran claves de localStorage)

| Antes (localStorage)       | Ahora (SQLite)                    |
|----------------------------|-----------------------------------|
| `pg_usuarios`, `pg_sesion` | `Usuario` + sesión de Django      |
| `pg_inventario`            | `Insumo`                          |
| `pg_movimientos`           | `Movimiento`                      |
| `pg_entregas`              | `Entrega`                         |
| `pg_prestamos`             | `Prestamo`                        |
| `pg_catalogo`              | `Catalogo`                        |
| `pg_reportes_estudiantes`  | `Reporte`                         |
| `pg_presupuesto`           | `Presupuesto` + `MovPresupuesto`  |
| `pg_consumo`               | `Curso` + `FilaConsumo`           |

Las contraseñas se guardan con hash de Django (PBKDF2), no en texto plano.

## Comandos útiles

```bash
python manage.py reiniciar_datos          # borra todo y vuelve a cargar los datos de ejemplo
python manage.py cambiar_password 12345678-9   # restablece la contraseña de un usuario
python manage.py test                     # corre las pruebas
python manage.py createsuperuser          # crea un usuario para el panel http://127.0.0.1:8000/admin/
```

El panel `/admin/` sirve para ver y editar las tablas. Es independiente del login del portal (que usa el modelo `Usuario`).

Para empezar de cero también puedes borrar `db.sqlite3` y volver a ejecutar `python manage.py migrate`.

## Imagen de la cocina (opcional)

Copia una foto como `portal/static/portal/img/cocina.jpg` y aparecerá de fondo (con el filtro azul) en la pantalla de registro.
