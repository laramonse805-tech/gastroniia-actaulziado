from django.urls import path

from . import api, views

urlpatterns = [
    path("", views.index, name="index"),
    path("login/", views.login_view, name="login"),
    path("registro/", views.registro_view, name="registro"),
    path("api/validar-rut/", views.validar_rut, name="validar_rut"),
    path("api/bootstrap/", api.bootstrap, name="api_bootstrap"),
    path("api/login/", api.login, name="api_login"),
    path("api/logout/", api.logout, name="api_logout"),
    path("api/registro/", api.registro, name="api_registro"),
    path("api/sync/", api.sync, name="api_sync"),
]

for slug in views.PAGINAS:
    urlpatterns.append(path(f"{slug}/", views.panel, {"page": slug}, name=slug))
