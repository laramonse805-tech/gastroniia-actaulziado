from django.contrib import admin

from .models import (
    Catalogo, Curso, Entrega, FilaConsumo, Insumo, Movimiento, MovPresupuesto,
    Prestamo, Presupuesto, Reporte, Usuario,
)


@admin.register(Usuario)
class UsuarioAdmin(admin.ModelAdmin):
    list_display = ("rut", "nombre", "apellido", "rol", "sede")
    list_filter = ("rol",)
    search_fields = ("rut", "nombre", "apellido")
    # La contraseña es un hash: para cambiarla usa  python manage.py cambiar_password RUT
    readonly_fields = ("password", "creado_en")


admin.site.register([Insumo, Movimiento, Entrega, Prestamo, Reporte, MovPresupuesto,
                     Presupuesto, Catalogo, Curso, FilaConsumo])
