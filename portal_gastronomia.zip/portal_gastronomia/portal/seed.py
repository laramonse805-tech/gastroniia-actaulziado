"""Datos de ejemplo. Se cargan solos la primera vez que corres `python manage.py migrate`."""
import uuid
from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.hashers import make_password
from django.db import transaction

from . import rut as rut_utils
from .models import (
    Catalogo, Curso, Entrega, FilaConsumo, Insumo, Movimiento, MovPresupuesto,
    Prestamo, Presupuesto, Reporte, Usuario,
)

MODELOS = [Reporte, Prestamo, Entrega, Movimiento, Insumo, MovPresupuesto, Presupuesto,
           Catalogo, Curso, FilaConsumo, Usuario]


def _id():
    return uuid.uuid4().hex[:12]


def _llenar(modelo, filas, con_id=True):
    # seq = posición, para conservar el orden en que se listan los datos de ejemplo
    modelo.objects.bulk_create([
        modelo(**({"id": _id(), "seq": i} if con_id else {}), **f) for i, f in enumerate(filas)
    ])


def _a_las(h, m=0):
    return datetime.now().replace(hour=h, minute=m, second=0, microsecond=0)


def _local(dt):  # 2026-09-30T08:30  (como isoLocal() en app.js)
    return dt.strftime("%Y-%m-%dT%H:%M")


def _utc(dt):  # 2026-09-30T12:30:00.000Z  (como toISOString() en app.js)
    return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _dias(n):
    return date.today() + timedelta(days=n)


@transaction.atomic
def sembrar():
    def usuario(nombre, apellido, cuerpo, clave, rol):
        return dict(
            nombre=nombre, apellido=apellido, rut=f"{cuerpo}-{rut_utils.digito_verificador(cuerpo)}",
            password=make_password(clave), region="Región Metropolitana", sede="Santiago Centro",
            rol=rol, documento={"nombre": "credencial.pdf", "size": 120000},
        )
    _llenar(Usuario, [
        usuario("Eugenia", "Rojas", "11111111", "Admin1234", "admin"),
        usuario("Sonía", "Muñoz", "22222222", "Cocina1234", "cocina"),
        usuario("Constanza", "Almonacid", "33333333", "Estudiante1234", "estudiante"),
        usuario("Pablo", "Fuentes", "44444444", "Docente1234", "docente"),
    ], con_id=False)

    def insumo(nombre, categoria, stock, minimo, unidad, dias, responsable, estado):
        return dict(nombre=nombre, categoria=categoria, stock=stock, min=minimo, unidad=unidad,
                    venc=_dias(dias), responsable=responsable, estado=estado)
    _llenar(Insumo, [
        insumo("Harina de Fuerza Trigo", "Panadería", 45, 10, "Kg", 30, "Carlos Valenzuela", "Disponible"),
        insumo("Mantequilla con Sal Colun", "Lácteos/Crema", 4.5, 8, "Kg", 10, "Carlos Valenzuela", "Stock Bajo"),
        insumo("Pisco de Cocina 35° Tres Erres", "Licores", 0, 2, "Lts", -20, "Sonía Muñoz", "Vencido"),
        insumo("Crema de Leche Soprole", "Lácteos/Crema", 28, 12, "Lts", 14, "Sonía Muñoz", "Disponible"),
        insumo("Azúcar Flor Iansa", "Panadería", 12, 6, "Kg", 45, "Carlos Valenzuela", "Disponible"),
        insumo("Queso Crema Philadelphia", "Lácteos/Crema", 6, 8, "Kg", -23, "Sonía Muñoz", "Vencido"),
    ])
    _llenar(Movimiento, [
        dict(tipo="entrada", titulo="Entrada de stock", detalle="Harina de Fuerza Trigo · 10.0 kg", valor="+10.0", ts=_utc(_a_las(9, 30))),
        dict(tipo="alerta", titulo="Alerta de stock bajo", detalle="Mantequilla con Sal Colun · 4.5 kg", valor="Bajo", ts=_utc(_a_las(9, 10))),
        dict(tipo="vencido", titulo="Producto vencido", detalle="Pisco de Cocina · 0.0 Lts", valor="Vencido", ts=_utc(_a_las(8, 50))),
    ])
    _llenar(Entrega, [
        dict(destino="cocina", detalle="Crema de Leche · 4.0 Lts", ts=_utc(_a_las(9, 20))),
        dict(destino="pastelería", detalle="Azúcar Flor · 2.0 kg", ts=_utc(_a_las(8, 45))),
        dict(destino="barra", detalle="Jugo de Naranja · 6.0 Lts", ts=_utc(_a_las(8, 10))),
    ])

    _llenar(Catalogo, [dict(codigo=c, nombre=n, tipo=t) for c, n, t in [
        ("UTE-SGC-004", 'Cuchillo Chef Profesional 8"', "Utensilio"),
        ("EQP-SGC-102", "Balanza Digital de Precisión", "Equipo"),
        ("EQP-SGC-088", "Batidora Planetaria 20 Lts", "Equipo"),
        ("UTE-SGC-145", "Sartén Antiadherente 26cm", "Utensilio"),
        ("UTE-SGC-201", "Termómetro de Cocina", "Utensilio"),
        ("UTE-SGC-310", "Cuchillo Medio Golpe Arcos", "Utensilio"),
        ("EQP-SGC-215", "Balanza de Gramaje Ohaus", "Equipo"),
        ("UTE-SGC-322", "Sartén de Teflón Profesional 24cm", "Utensilio"),
        ("UTE-SGC-330", "Espátula de Silicona", "Utensilio"),
        ("EQP-SGC-240", "Horno Convector Portátil", "Equipo"),
    ]], con_id=False)

    def prestamo(codigo, nombre, tipo, usuario, rut, estado, dano="", devuelto=False):
        return dict(codigo=codigo, nombre=nombre, tipo=tipo, usuario=usuario, rut=rut, estado=estado, dano=dano,
                    prestamo=_local(_a_las(8, 30)), dev_prevista=_local(_a_las(13)),
                    dev_real=_local(_a_las(12, 50)) if devuelto else None)
    andres = ("Andrés Silva Valdés", "19.345.102-3")
    constanza = ("Constanza Almonacid", "33.333.333-3")
    _llenar(Prestamo, [
        prestamo("UTE-SGC-004", 'Cuchillo Chef Profesional 8"', "Utensilio", *andres, "Pendiente"),
        prestamo("EQP-SGC-102", "Balanza Digital de Precisión", "Equipo", "Fernanda Gómez", "20.111.222-3", "Devuelto", devuelto=True),
        prestamo("EQP-SGC-088", "Batidora Planetaria 20 Lts", "Equipo", *andres, "Pendiente"),
        prestamo("UTE-SGC-145", "Sartén Antiadherente 26cm", "Utensilio", "Mario Soto", "18.777.888-9", "Devuelto", devuelto=True),
        prestamo("UTE-SGC-201", "Termómetro de Cocina", "Utensilio", *andres, "Con daños", "Sensor descalibrado"),
        prestamo("UTE-SGC-310", "Cuchillo Medio Golpe Arcos", "Utensilio", *constanza, "Pendiente"),
        prestamo("EQP-SGC-215", "Balanza de Gramaje Ohaus", "Equipo", *constanza, "Pendiente"),
        prestamo("UTE-SGC-322", "Sartén de Teflón Profesional 24cm", "Utensilio", *constanza, "Pendiente"),
    ])

    Presupuesto.objects.create(inicial=5000000)
    _llenar(MovPresupuesto, [
        dict(ts="2026-09-02T11:15", desc="Servicio Técnico Hornos Conectores Industriales", tipo="Egreso", monto=420000, resp="Eugenia Rojas"),
        dict(ts="2026-09-08T09:30", desc="Factura Proveedor Colun - Lácteos Prácticas", tipo="Egreso", monto=780000, resp="Eugenia Rojas"),
        dict(ts="2026-09-10T14:00", desc="Reposición de Caja Chica Operativa Sede", tipo="Ingreso", monto=1500000, resp="Eugenia Rojas"),
        dict(ts="2026-09-14T10:45", desc="Adquisición Chocolate de Repostería Bitter", tipo="Egreso", monto=350000, resp="Sonía Muñoz"),
    ])

    _llenar(Curso, [
        dict(nombre="Pastelería Profesional IV", est=32, rec=6, kg=124.8, color="#0033a0"),
        dict(nombre="Panadería y Masa Madre", est=28, rec=4, kg=96.4, color="#16a34a"),
        dict(nombre="Repostería y Decoración", est=24, rec=5, kg=88.2, color="#d97706"),
    ], con_id=False)

    def fila(curso, curso_full, receta, fecha, insumos, kg, clases, docente, estado):
        return dict(curso=curso, curso_full=curso_full, receta=receta, fecha=fecha, insumos=insumos,
                    kg=kg, clases=clases, docente=docente, estado=estado)
    past, pan, rep = "Pastelería Profesional IV", "Panadería y Masa Madre", "Repostería y Decoración"
    _llenar(FilaConsumo, [
        fila("Pastelería IV", past, "Macarons de Frambuesa y Pistacho", "2026-03-12", 8, 13.2, 3, "Chef P. Fuentes", "Ajustado"),
        fila("Panadería III", pan, "Baguette Tradicional y Masa Madre", "2026-03-10", 6, 29.8, 4, "Chef J. Valenzuela", "Óptimo"),
        fila("Repostería II", rep, "Torta de Novia Tres Leches Chilena", "2026-03-05", 9, 18.1, 2, "Chef M. Almonacid", "Excedido"),
        fila("Pastelería IV", past, "Milhojas de Manjar", "2026-03-19", 7, 9.6, 2, "Chef P. Fuentes", "Óptimo"),
        fila("Repostería II", rep, "Brazo de Reina con Frambuesa", "2026-03-26", 5, 7.4, 1, "Chef M. Almonacid", "Ajustado"),
    ], con_id=False)


def cargar_si_vacio():
    if not Usuario.objects.exists():
        sembrar()


@transaction.atomic
def reiniciar():
    for modelo in MODELOS:
        modelo.objects.all().delete()
    sembrar()
