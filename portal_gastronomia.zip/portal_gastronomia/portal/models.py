"""Tablas de SQLite (db.sqlite3). Reemplazan las claves que antes vivían en localStorage.

pg_usuarios -> Usuario            pg_inventario -> Insumo        pg_movimientos -> Movimiento
pg_entregas -> Entrega            pg_prestamos  -> Prestamo      pg_catalogo    -> Catalogo
pg_reportes_estudiantes -> Reporte
pg_presupuesto -> Presupuesto + MovPresupuesto
pg_consumo -> Curso + FilaConsumo
"""
import time

from django.db import models

ROLES = ("admin", "cocina", "docente", "estudiante")


class Usuario(models.Model):
    rut = models.CharField(max_length=12, unique=True)  # sin puntos, con guión: 12345678-9
    password = models.CharField(max_length=128)  # hash de Django (PBKDF2), nunca la clave en texto
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    region = models.CharField(max_length=100)
    sede = models.CharField(max_length=100)
    rol = models.CharField(max_length=20, choices=[(r, r) for r in ROLES])
    documento = models.JSONField(default=dict)  # {nombre, size, tipo} del archivo de validación
    creado_en = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombre} {self.apellido} ({self.rut})"

    def publico(self):
        """Datos que sí pueden viajar al navegador (sin el hash de la contraseña)."""
        return {
            "id": self.pk, "rut": self.rut, "nombre": self.nombre, "apellido": self.apellido,
            "region": self.region, "sede": self.sede, "rol": self.rol,
            "documento": self.documento, "creadoEn": self.creado_en.isoformat(),
        }


class Base(models.Model):
    """Registros que el navegador crea con su propio id (uid() en app.js).

    `seq` conserva el orden de creación, igual que el orden del arreglo en localStorage.
    """
    id = models.CharField(primary_key=True, max_length=40)
    seq = models.BigIntegerField(default=time.time_ns, editable=False, db_index=True)

    class Meta:
        abstract = True
        ordering = ["seq", "id"]


class Insumo(Base):
    nombre = models.CharField(max_length=200)
    categoria = models.CharField(max_length=100)
    stock = models.FloatField()
    min = models.FloatField()
    unidad = models.CharField(max_length=10)
    venc = models.DateField()
    responsable = models.CharField(max_length=200)
    estado = models.CharField(max_length=20)


class Movimiento(Base):
    tipo = models.CharField(max_length=20)
    titulo = models.CharField(max_length=200)
    detalle = models.CharField(max_length=300)
    valor = models.CharField(max_length=40)
    ts = models.CharField(max_length=32)  # ISO tal como lo genera el navegador


class Entrega(Base):
    destino = models.CharField(max_length=100)
    detalle = models.CharField(max_length=300)
    ts = models.CharField(max_length=32)


class Prestamo(Base):
    codigo = models.CharField(max_length=40)
    nombre = models.CharField(max_length=200)
    tipo = models.CharField(max_length=20)
    usuario = models.CharField(max_length=200, blank=True)
    rut = models.CharField(max_length=14, blank=True)  # puede venir con puntos (19.345.102-3)
    estado = models.CharField(max_length=20)
    dano = models.CharField(max_length=500, blank=True)
    prestamo = models.CharField(max_length=32)
    dev_prevista = models.CharField(max_length=32)
    dev_real = models.CharField(max_length=32, null=True, blank=True)


class Reporte(Base):
    ts = models.CharField(max_length=32)
    rut = models.CharField(max_length=12)
    estudiante = models.CharField(max_length=200)
    clase = models.CharField(max_length=100)
    items = models.JSONField(default=list)  # [{codigo, nombre, tipo, devuelto, dano, desc}]
    verificado = models.BooleanField(default=False)


class MovPresupuesto(Base):
    ts = models.CharField(max_length=32)
    desc = models.CharField(max_length=300)
    tipo = models.CharField(max_length=10)  # Ingreso | Egreso
    monto = models.BigIntegerField()
    resp = models.CharField(max_length=200)


class Presupuesto(models.Model):
    """Una sola fila: presupuesto inicial aprobado."""
    inicial = models.BigIntegerField(default=0)


# ---- Tablas de solo lectura (datos de ejemplo cargados al migrar) ----
class Catalogo(models.Model):
    codigo = models.CharField(max_length=40, unique=True)
    nombre = models.CharField(max_length=200)
    tipo = models.CharField(max_length=20)

    class Meta:
        ordering = ["id"]


class Curso(models.Model):
    nombre = models.CharField(max_length=200)
    est = models.IntegerField()
    rec = models.IntegerField()
    kg = models.FloatField()
    color = models.CharField(max_length=9)

    class Meta:
        ordering = ["id"]


class FilaConsumo(models.Model):
    curso = models.CharField(max_length=100)
    curso_full = models.CharField(max_length=200)
    receta = models.CharField(max_length=200)
    fecha = models.DateField()
    insumos = models.IntegerField()
    kg = models.FloatField()
    clases = models.IntegerField()
    docente = models.CharField(max_length=100)
    estado = models.CharField(max_length=20)

    class Meta:
        ordering = ["id"]
