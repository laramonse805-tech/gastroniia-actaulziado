"""API JSON del portal. app.js la usa en lugar de localStorage; todo queda en SQLite.

GET  /api/bootstrap/  -> usuario con sesión + los datos que su rol puede ver
POST /api/login/      -> {rut, password}
POST /api/logout/
POST /api/registro/   -> crea una cuenta
POST /api/sync/       -> {coleccion: {upsert: [items], delete: [ids]}} (solo lo que cambió)
"""
import json
import re
from datetime import date
from functools import wraps

from django.contrib.auth.hashers import check_password, make_password
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.http import JsonResponse
from django.views.decorators.cache import never_cache

from . import rut as rut_utils
from .models import (
    ROLES, Base, Catalogo, Curso, Entrega, FilaConsumo, Insumo, Movimiento,
    MovPresupuesto, Prestamo, Presupuesto, Reporte, Usuario,
)

TODOS = set(ROLES)

# colección (mismo nombre que usa app.js) -> (modelo, roles que leen, roles que escriben)
COLECCIONES = {
    "inventario": (Insumo, TODOS, {"cocina"}),
    "movimientos": (Movimiento, {"cocina"}, {"cocina"}),
    "entregas": (Entrega, {"cocina"}, {"cocina"}),
    "prestamos": (Prestamo, TODOS, {"cocina", "estudiante"}),
    "reportes": (Reporte, {"cocina", "estudiante"}, {"cocina", "estudiante"}),
    "presupuesto_movs": (MovPresupuesto, {"admin"}, {"admin"}),
}


class ApiError(Exception):
    def __init__(self, mensaje, status=400):
        super().__init__(mensaje)
        self.mensaje, self.status = mensaje, status


def error(mensaje, status=400):
    return JsonResponse({"error": mensaje}, status=status)


def usuario_actual(request):
    pk = request.session.get("usuario_id")
    return Usuario.objects.filter(pk=pk).first() if pk else None


def endpoint(metodo="POST", login=True):
    """Valida método, sesión y JSON; traduce ApiError a una respuesta con su mensaje."""
    def deco(fn):
        @wraps(fn)
        def vista(request):
            if request.method != metodo:
                return error("Método no permitido.", 405)
            usuario = usuario_actual(request)
            if login and not usuario:
                return error("Tu sesión expiró. Vuelve a iniciar sesión.", 401)
            datos = {}
            if metodo == "POST":
                try:
                    datos = json.loads(request.body or b"{}")
                except ValueError:
                    return error("JSON inválido.")
                if not isinstance(datos, dict):
                    return error("JSON inválido.")
            try:
                return fn(request, usuario, datos)
            except ApiError as e:
                return error(e.mensaje, e.status)
            except IntegrityError:
                return error("Datos incompletos o repetidos.")
        return never_cache(vista)
    return deco


# ---------- conversión modelo <-> JSON (snake_case <-> camelCase) ----------
def camel(s):
    return re.sub(r"_([a-z])", lambda m: m.group(1).upper(), s)


def snake(s):
    return re.sub(r"([A-Z])", lambda m: "_" + m.group(1).lower(), s)


def a_dict(obj):
    d = {}
    for f in obj._meta.concrete_fields:
        if f.name == "seq" or (f.name == "id" and not isinstance(obj, Base)):
            continue
        v = getattr(obj, f.attname)
        d[camel(f.name)] = v.isoformat() if isinstance(v, date) else v
    return d


def limpiar_valor(campo, valor):
    try:
        v = campo.to_python(valor)
    except ValidationError:
        raise ApiError(f"Valor inválido en «{camel(campo.name)}».")
    if v is None and not campo.null:
        raise ApiError(f"Falta «{camel(campo.name)}».")
    if isinstance(v, str) and campo.max_length and len(v) > campo.max_length:
        raise ApiError(f"«{camel(campo.name)}» es demasiado largo.")
    return v


# ---------- lectura ----------
def filas_visibles(coleccion, usuario):
    modelo = COLECCIONES[coleccion][0]
    filas = [a_dict(o) for o in modelo.objects.all()]
    if usuario.rol == "estudiante":
        if coleccion == "reportes":  # solo sus propios reportes
            filas = [f for f in filas if f["rut"] == usuario.rut]
        elif coleccion == "prestamos":  # de los demás solo se ve qué código está ocupado
            filas = [f if rut_utils.limpiar(f["rut"]) == usuario.rut
                     else {**f, "usuario": "", "rut": "", "dano": ""} for f in filas]
    return filas


@endpoint("GET", login=False)
def bootstrap(request, usuario, _):
    if not usuario:
        return JsonResponse({"usuario": None, "datos": {}})
    datos = {}
    for coleccion, info in COLECCIONES.items():
        if usuario.rol in info[1] and coleccion != "presupuesto_movs":
            datos[coleccion] = filas_visibles(coleccion, usuario)
    datos["catalogo"] = [a_dict(c) for c in Catalogo.objects.all()]
    if usuario.rol in COLECCIONES["presupuesto_movs"][1]:
        base = Presupuesto.objects.first()
        datos["presupuesto"] = {
            "inicial": base.inicial if base else 0,
            "movs": filas_visibles("presupuesto_movs", usuario),
        }
    if usuario.rol in ("admin", "docente"):
        datos["consumo"] = {
            "cursos": [a_dict(c) for c in Curso.objects.all()],
            "filas": [a_dict(f) for f in FilaConsumo.objects.all()],
        }
    return JsonResponse({"usuario": usuario.publico(), "datos": datos})


# ---------- sesión y cuentas ----------
@endpoint(login=False)
def login(request, _, d):
    rut = rut_utils.limpiar(d.get("rut"))
    u = Usuario.objects.filter(rut=rut).first()
    if not u or not check_password(str(d.get("password") or ""), u.password):
        raise ApiError("RUT o contraseña incorrectos.", 401)
    request.session.cycle_key()
    request.session["usuario_id"] = u.pk
    return JsonResponse({"usuario": u.publico()})


@endpoint(login=False)
def logout(request, _, d):
    request.session.flush()
    return JsonResponse({"ok": True})


@endpoint(login=False)
def registro(request, _, d):
    texto = lambda k: str(d.get(k) or "").strip()
    nombre, apellido, region, sede = texto("nombre"), texto("apellido"), texto("region"), texto("sede")
    rut, password, rol = rut_utils.limpiar(d.get("rut")), str(d.get("password") or ""), d.get("rol")
    doc = d.get("documento") if isinstance(d.get("documento"), dict) else {}
    if not nombre or not apellido:
        raise ApiError("Ingresa tu nombre y apellido.")
    if max(len(nombre), len(apellido), len(region), len(sede)) > 100 or not region or not sede:
        raise ApiError("Revisa tu nombre, región y sede.")
    if not rut_utils.es_valido(rut):
        raise ApiError("El RUT no es válido. Revisa el dígito verificador.")
    if not 8 <= len(password) <= 128:
        raise ApiError("La contraseña debe tener al menos 8 caracteres.")
    if rol not in ROLES:
        raise ApiError("Elige un rol válido.")
    nombre_doc = str(doc.get("nombre") or "")
    try:
        size = int(doc.get("size") or 0)
    except (TypeError, ValueError):
        size = -1
    if nombre_doc.lower().rsplit(".", 1)[-1] not in ("pdf", "png") or not 0 <= size <= 10 * 1024 * 1024:
        raise ApiError("Sube tu documento de validación de rol (.PDF o .PNG, máx. 10MB).")
    if Usuario.objects.filter(rut=rut).exists():
        raise ApiError("Ya existe una cuenta con ese RUT.", 409)
    Usuario.objects.create(
        rut=rut, password=make_password(password), nombre=nombre, apellido=apellido, region=region,
        sede=sede, rol=rol, documento={"nombre": nombre_doc[:200], "size": size, "tipo": str(doc.get("tipo") or "")[:100]},
    )
    return JsonResponse({"ok": True}, status=201)


# ---------- escritura ----------
def es_propio(usuario, rut):
    return rut_utils.limpiar(rut) == usuario.rut


def guardar_item(coleccion, modelo, item, usuario):
    pk = item.get("id") if isinstance(item, dict) else None
    if not isinstance(pk, str) or not re.fullmatch(r"[\w-]{1,40}", pk):
        raise ApiError("Elemento sin id válido.")
    obj = modelo.objects.filter(pk=pk).first()
    if usuario.rol == "estudiante":  # un estudiante solo toca lo suyo
        if coleccion == "prestamos" and (not es_propio(usuario, item.get("rut")) or (obj and not es_propio(usuario, obj.rut))):
            raise ApiError("No puedes modificar elementos de otra persona.", 403)
        if coleccion == "reportes" and (obj or not es_propio(usuario, item.get("rut"))):
            raise ApiError("No puedes modificar reportes de otra persona.", 403)
    campos = {f.name: f for f in modelo._meta.concrete_fields if f.name not in ("id", "seq")}
    valores = {n: limpiar_valor(campos[n], v) for n, v in ((snake(k), v) for k, v in item.items()) if n in campos}
    if obj:
        for n, v in valores.items():
            setattr(obj, n, v)
        obj.save()
    else:
        modelo.objects.create(id=pk, **valores)


@endpoint()
def sync(request, usuario, datos):
    with transaction.atomic():
        for coleccion, cambios in datos.items():
            if coleccion not in COLECCIONES or not isinstance(cambios, dict):
                raise ApiError(f"Colección desconocida: {coleccion}.")
            modelo, _, escribe = COLECCIONES[coleccion]
            if usuario.rol not in escribe:
                raise ApiError("Tu rol no puede modificar esta información.", 403)
            for item in cambios.get("upsert") or []:
                guardar_item(coleccion, modelo, item, usuario)
            borrar = cambios.get("delete") or []
            if borrar:
                if usuario.rol == "estudiante":
                    raise ApiError("Tu rol no puede eliminar registros.", 403)
                modelo.objects.filter(pk__in=[str(i) for i in borrar]).delete()
    return JsonResponse({"ok": True})
