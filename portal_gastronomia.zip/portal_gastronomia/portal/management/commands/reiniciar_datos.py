from django.core.management.base import BaseCommand

from portal import seed


class Command(BaseCommand):
    help = "Borra TODOS los datos (usuarios incluidos) y vuelve a cargar los datos de ejemplo."

    def add_arguments(self, parser):
        parser.add_argument("--si", action="store_true", help="No pedir confirmación")

    def handle(self, *args, **opts):
        if not opts["si"] and input("Esto borra todos los datos. Escribe 'si' para continuar: ").strip().lower() != "si":
            self.stdout.write("Cancelado.")
            return
        seed.reiniciar()
        self.stdout.write(self.style.SUCCESS("Datos de ejemplo cargados."))
