from getpass import getpass

from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand, CommandError

from portal import rut as rut_utils
from portal.models import Usuario


class Command(BaseCommand):
    help = "Cambia la contraseña de un usuario: python manage.py cambiar_password 12345678-9"

    def add_arguments(self, parser):
        parser.add_argument("rut")

    def handle(self, *args, **opts):
        u = Usuario.objects.filter(rut=rut_utils.limpiar(opts["rut"])).first()
        if not u:
            raise CommandError("No existe un usuario con ese RUT.")
        clave = getpass("Nueva contraseña (mínimo 8 caracteres): ")
        if len(clave) < 8:
            raise CommandError("La contraseña debe tener al menos 8 caracteres.")
        u.password = make_password(clave)
        u.save(update_fields=["password"])
        self.stdout.write(self.style.SUCCESS(f"Contraseña actualizada para {u}."))
