import json

from django.test import Client, TestCase

from .models import Insumo, MovPresupuesto, Prestamo, Reporte, Usuario

CUENTAS = {  # rol -> (rut, contraseña) de los datos de ejemplo
    "admin": ("11111111-1", "Admin1234"),
    "cocina": ("22222222-2", "Cocina1234"),
    "estudiante": ("33333333-3", "Estudiante1234"),
    "docente": ("44444444-4", "Docente1234"),
}


class ApiTests(TestCase):
    def entrar(self, rol):
        c = Client()
        rut, clave = CUENTAS[rol]
        r = c.post("/api/login/", {"rut": rut, "password": clave}, content_type="application/json")
        self.assertEqual(r.status_code, 200, r.content)
        return c

    def sync(self, c, cuerpo):
        return c.post("/api/sync/", json.dumps(cuerpo), content_type="application/json")

    def test_login_y_bootstrap(self):
        c = Client()
        self.assertIsNone(c.get("/api/bootstrap/").json()["usuario"])
        r = c.post("/api/login/", {"rut": "11.111.111-1", "password": "mala"}, content_type="application/json")
        self.assertEqual(r.status_code, 401)
        c = self.entrar("cocina")
        b = c.get("/api/bootstrap/").json()
        self.assertEqual(b["usuario"]["rol"], "cocina")
        self.assertNotIn("password", b["usuario"])
        self.assertEqual(len(b["datos"]["inventario"]), 6)
        self.assertNotIn("presupuesto", b["datos"])  # solo el admin

    def test_la_clave_se_guarda_con_hash(self):
        self.assertTrue(Usuario.objects.get(rut="11111111-1").password.startswith(("pbkdf2_", "argon2", "scrypt")))

    def test_cocina_crea_edita_y_elimina_insumos(self):
        c = self.entrar("cocina")
        item = {"id": "abc123", "nombre": "Sal", "categoria": "Abarrotes", "stock": 3, "min": 1,
                "unidad": "Kg", "venc": "2027-01-31", "responsable": "Sonía", "estado": "Disponible"}
        self.assertEqual(self.sync(c, {"inventario": {"upsert": [item], "delete": []}}).status_code, 200)
        self.assertEqual(Insumo.objects.get(pk="abc123").stock, 3)
        item["stock"] = 0.5
        self.sync(c, {"inventario": {"upsert": [item], "delete": []}})
        self.assertEqual(Insumo.objects.get(pk="abc123").stock, 0.5)
        self.assertEqual(Insumo.objects.filter(pk="abc123").count(), 1)
        self.sync(c, {"inventario": {"upsert": [], "delete": ["abc123"]}})
        self.assertFalse(Insumo.objects.filter(pk="abc123").exists())

    def test_datos_invalidos_no_guardan_nada(self):
        c = self.entrar("cocina")
        malo = {"id": "x1", "nombre": "Sal", "categoria": "A", "stock": "mucho", "min": 1, "unidad": "Kg",
                "venc": "2027-01-31", "responsable": "", "estado": "Disponible"}
        self.assertEqual(self.sync(c, {"inventario": {"upsert": [malo]}}).status_code, 400)
        self.assertFalse(Insumo.objects.filter(pk="x1").exists())

    def test_permisos_por_rol(self):
        nuevo = {"id": "n1", "nombre": "X", "categoria": "A", "stock": 1, "min": 1, "unidad": "Kg",
                 "venc": "2027-01-31", "responsable": "", "estado": "Disponible"}
        for rol in ("admin", "docente", "estudiante"):
            r = self.sync(self.entrar(rol), {"inventario": {"upsert": [nuevo]}})
            self.assertEqual(r.status_code, 403, rol)
        mov = {"id": "p1", "ts": "2026-09-30T10:00", "desc": "Compra", "tipo": "Egreso", "monto": 1000, "resp": "Eugenia"}
        self.assertEqual(self.sync(self.entrar("cocina"), {"presupuesto_movs": {"upsert": [mov]}}).status_code, 403)
        self.assertEqual(self.sync(self.entrar("admin"), {"presupuesto_movs": {"upsert": [mov]}}).status_code, 200)
        self.assertEqual(MovPresupuesto.objects.get(pk="p1").monto, 1000)
        self.assertEqual(Insumo.objects.filter(pk="n1").count(), 0)

    def test_sin_sesion_no_escribe(self):
        r = Client().post("/api/sync/", "{}", content_type="application/json")
        self.assertEqual(r.status_code, 401)

    def test_estudiante_solo_ve_y_toca_lo_suyo(self):
        c = self.entrar("estudiante")
        datos = c.get("/api/bootstrap/").json()["datos"]
        ajenos = [p for p in datos["prestamos"] if p["codigo"] == "UTE-SGC-004"][0]
        self.assertEqual((ajenos["usuario"], ajenos["rut"]), ("", ""))  # se oculta quién lo tiene
        self.assertNotIn("movimientos", datos)
        propio = [p for p in datos["prestamos"] if p["codigo"] == "UTE-SGC-310"][0]
        propio["estado"] = "Devuelto"
        self.assertEqual(self.sync(c, {"prestamos": {"upsert": [propio]}}).status_code, 200)
        self.assertEqual(Prestamo.objects.get(pk=propio["id"]).estado, "Devuelto")
        ajenos["rut"] = "33.333.333-3"  # intenta apropiarse de un préstamo ajeno
        self.assertEqual(self.sync(c, {"prestamos": {"upsert": [ajenos]}}).status_code, 403)
        self.assertEqual(self.sync(c, {"prestamos": {"delete": [propio["id"]]}}).status_code, 403)
        rep = {"id": "r1", "ts": "2026-09-30T12:00:00.000Z", "rut": "33333333-3", "estudiante": "Constanza",
               "clase": "Cocina Fría", "items": [{"codigo": "UTE-SGC-310"}], "verificado": False}
        self.assertEqual(self.sync(c, {"reportes": {"upsert": [rep]}}).status_code, 200)
        rep["verificado"] = True  # no puede auto-verificarse
        self.assertEqual(self.sync(c, {"reportes": {"upsert": [rep]}}).status_code, 403)
        self.assertFalse(Reporte.objects.get(pk="r1").verificado)
        self.assertEqual(self.sync(self.entrar("cocina"), {"reportes": {"upsert": [rep]}}).status_code, 200)
        self.assertTrue(Reporte.objects.get(pk="r1").verificado)

    def test_registro(self):
        c = Client()
        base = {"nombre": "Ana", "apellido": "Pérez", "rut": "12.345.678-5", "password": "clave1234",
                "region": "Biobío", "sede": "Concepción", "rol": "estudiante",
                "documento": {"nombre": "cred.pdf", "size": 1000, "tipo": "application/pdf"}}
        post = lambda **kw: c.post("/api/registro/", {**base, **kw}, content_type="application/json")
        self.assertEqual(post(rut="12.345.678-9").status_code, 400)  # dígito verificador malo
        self.assertEqual(post(password="corta").status_code, 400)
        self.assertEqual(post(rol="superadmin").status_code, 400)
        self.assertEqual(post(documento={"nombre": "x.exe", "size": 5}).status_code, 400)
        self.assertEqual(post().status_code, 201)
        self.assertEqual(post().status_code, 409)  # RUT repetido
        r = c.post("/api/login/", {"rut": "12345678-5", "password": "clave1234"}, content_type="application/json")
        self.assertEqual(r.status_code, 200)

    def test_exige_csrf(self):
        c = Client(enforce_csrf_checks=True)
        r = c.post("/api/login/", {"rut": "11111111-1", "password": "Admin1234"}, content_type="application/json")
        self.assertEqual(r.status_code, 403)
        c.get("/login/")  # entrega la cookie csrftoken
        token = c.cookies["csrftoken"].value
        r = c.post("/api/login/", {"rut": "11111111-1", "password": "Admin1234"},
                   content_type="application/json", headers={"X-CSRFToken": token})
        self.assertEqual(r.status_code, 200)
