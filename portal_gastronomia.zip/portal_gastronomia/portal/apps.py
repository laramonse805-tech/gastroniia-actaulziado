from django.apps import AppConfig
from django.db.models.signals import post_migrate


def _cargar_datos_de_ejemplo(sender, **kwargs):
    from .seed import cargar_si_vacio
    cargar_si_vacio()  # solo si la base está vacía


class PortalConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "portal"

    def ready(self):
        post_migrate.connect(_cargar_datos_de_ejemplo, sender=self)
